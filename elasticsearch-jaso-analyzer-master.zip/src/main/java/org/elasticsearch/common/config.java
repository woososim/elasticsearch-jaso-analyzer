package org.elasticsearch.common;

/**
 * 글로벌 공통변수
 *
 * @author 최일규
 * @since 2016-02-03
 */
public class config {
    public static final char SPLIT_CHAR = '♥';
    public static final char WHITESPACE_CHAR = ' ';
}